package com.example.sqlapi;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private TextView resultsTextView;
    private RequestQueue queue; // Declare the RequestQueue at the class level

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultsTextView = findViewById(R.id.tvResults);
        queue = Volley.newRequestQueue(this); // Initialize the RequestQueue here

        Button fetchDataButton = findViewById(R.id.buttonFetch);
        fetchDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchData();
            }
        });
    }

    public void submitData(View view) {
        EditText nameEditText = findViewById(R.id.editTextName);
        EditText ageEditText = findViewById(R.id.editTextAge);
        EditText gradeEditText = findViewById(R.id.editTextGrade);

        String name = nameEditText.getText().toString();
        String ageStr = ageEditText.getText().toString();
        String grade = gradeEditText.getText().toString();

        if (name.isEmpty() || ageStr.isEmpty() || grade.isEmpty()) {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid age entered", Toast.LENGTH_SHORT).show();
            return;
        }
        postData(name, age, grade);
    }

    public void fetchData() {
        String url = "http://10.0.2.2/Android/API/fetch_students.php";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> resultsTextView.setText("Response: " + response),
                error -> {
                    Log.e("fetchData", "Error: " + error.toString());
                    Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                });
        queue.add(stringRequest);
    }

    private void postData(String name, int age, String grade) {
        String url = "http://10.0.2.2/Android/API/add_student.php";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                response -> Toast.makeText(MainActivity.this, "Data posted successfully!", Toast.LENGTH_SHORT).show(),
                error -> {
                    Log.e("postData", "Post failed: " + error.toString());
                    Toast.makeText(MainActivity.this, "Post failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("age", String.valueOf(age));
                params.put("grade", grade);
                return params;
            }
        };
        queue.add(postRequest);
    }
}